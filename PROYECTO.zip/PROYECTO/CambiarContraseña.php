<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/6. styleCambiar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poiret+One&family=Prata&family=Savate:ital,wght@0,200..900;1,200..900&display=swap" rel="stylesheet">
    <title>Administrdor</title>
</head>
<header class="py-3 shadow-sm">
  <div class="container">
    <div class="row g-0 justify-content-between align-items-center">
        <!-- Logo + Título -->
        <div class="col-auto d-flex align-items-center ps-2">
            <img src="img/Logo Vibra Positiva.jpg" alt="Logo" class="minilogo me-2">
            <h1 class="titulo fw-bold text-uppercase mb-0 fs-7 ms-4 poiret-one-font">Vibra Positiva Pijamas</h1>
        </div>
        <nav class="menu col-auto d-flex flex-column flex-md-row align-items-center gap-1 gap-md-2">
            <a href="1. index.html" class="co1 px-3 d-flex align-items-center text-center text-black text-decoration-none">
                <div class="login poiret-one-font fw-bold d-flex align-items-center gap-1">
                     <span><a href="logout.php" class="btn btn-danger">Cerrar sesión</a>
</span>
                    <div class="icono">
                        <i class="bi bi-box-arrow-left"></i>
                    </div>
                </div>
            </a>
        </nav>
    </div>
  </div>
</header>
<body class="poiret-one-font fw-bold">
    <h1>Cambiar Contraseña</h1>

  <form class="password-form" id="formCambio">
    <div class="form-group">
      <label for="oldPassword">Contraseña Antigua</label>
      <input type="password" id="oldPassword" class="form-control" required />
    </div>
    <div class="form-group">
      <label for="newPassword">Contraseña Nueva</label>
      <input type="password" id="newPassword" class="form-control" required />
    </div>
    <div class="form-group">
      <label for="repeatPassword">Repetir Contraseña</label>
      <input type="password" id="repeatPassword" class="form-control" required />
    </div>
    <div class="button-container">
      <button type="submit" class="btn btn-primary">Finalizar</button>
    </div>
    <div class="text-link">
      <a data-bs-toggle="modal" data-bs-target="#modalRecuperar">¿Olvidó su contraseña?</a>
    </div>
  </form>

  <!-- Modal: Contraseña cambiada con éxito -->
  <div class="modal fade" id="modalExito" tabindex="-1" aria-labelledby="modalExitoLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header bg-success text-white">
          <h5 class="modal-title" id="modalExitoLabel">¡Éxito!</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          Tu contraseña ha sido cambiada correctamente.
        </div>
        <div class="modal-footer">
          <a href="4. Administrador.html" class="btn btn-success">Aceptar</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal: Recuperar contraseña -->
  <div class="modal fade" id="modalRecuperar" tabindex="-1" aria-labelledby="modalRecuperarLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <form id="formRecuperar">
          <div class="modal-header">
            <h5 class="modal-title" id="modalRecuperarLabel">Recuperar Contraseña</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <label for="correoRecuperar" class="form-label">Ingresa tu correo electrónico:</label>
            <input type="email" id="correoRecuperar" class="form-control" required />
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary">Enviar</button>
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Modal: Contraseña temporal -->
  <div class="modal fade" id="modalTemporal" tabindex="-1" aria-labelledby="modalTemporalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header bg-warning">
          <h5 class="modal-title" id="modalTemporalLabel">Contraseña Temporal</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          Se ha enviado una contraseña temporal a tu correo.<br><br>
          <strong>Contraseña temporal:</strong>
          <span id="claveTemporalOculta">********</span>
          <span id="claveTemporalReal" style="display:none;" class="text-danger fw-bold"></span>
          <button class="btn btn-sm btn-outline-secondary ms-2" id="btnToggleClave" type="button">Mostrar</button>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-warning" data-bs-dismiss="modal" onclick="window.location.href='1. index.html'">Aceptar</button>
        </div>
      </div>
    </div>
  </div>

</footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="js/6. appcambiarContraseña.js"></script>
</body>
</html>