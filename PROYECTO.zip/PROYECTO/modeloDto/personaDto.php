<?php
class UsuarioDto {
    private $rolPersona ="";
    private $primerNombre = "";
    private $segundoNombre = "";
    private $primerApellido = "";
    private $segundoApellido = "";
    private $tipoDocumento = "";
    private $numeroDocumento =0;
    private $correo = "";
    private $telefono = 0;
    private $contrasena = "";

    public function getRolPersona() 
    { 
        return $this->rolPersona; 
    }
    public function setRolPersona($rolPersona) 
    { 
        $this->rolPersona = $rolPersona; 
    }

    public function getPrimerNombre() 
    { 
        return $this->primerNombre; 
    }
    public function setPrimerNombre($primerNombre) 
    { 
        $this->primerNombre = $primerNombre;
    }

    public function getSegundoNombre() 
    { 
        return $this->segundoNombre; 
    }
    public function setSegundoNombre($segundoNombre) 
    {
         $this->segundoNombre = $segundoNombre ; 
    }

    public function getPrimerApellido() 
    { return $this->primerApellido; 
    }
    public function setPrimerApellido($primerApellido) 
    { $this->primerApellido = $primerApellido; 
    }

    public function getSegundoApellido() { 
        return $this->segundoApellido; 
    }
    public function setSegundoApellido($segundoApellido) {
         $this->segundoApellido = $segundoApellido;
         }

    public function getTipoDocumento() { 
        return $this->tipoDocumento; 
    }
    public function setTipoDocumento($tipoDocumento) { 
        $this->tipoDocumento = $tipoDocumento; 
    }

    public function getNumeroDocumento() { 
        return $this->numeroDocumento;
     }
    public function setNumeroDocumento($numeroDocumento) {
         $this->numeroDocumento = $numeroDocumento;
         }

    public function getCorreo() { 
        return $this->correo;
     }
    public function setCorreo($correo) { 
        $this->correo = $correo;
     }

    public function getTelefono() { 
        return $this->telefono; 
    }
    public function setTelefono($telefono) { 
        $this->telefono = $telefono; 
    }

    public function getContrasena() {
         return $this->contrasena;
         }
    public function setContrasena($contrasena) { 
        $this->contrasena = $contrasena; 
    }
}
?>
