<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/3. styleAdmin.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Merriweather:ital,opsz,wght@0,18..144,300..900;1,18..144,300..900&family=Poiret+One&family=Prata&family=Savate:ital,wght@0,200..900;1,200..900&display=swap" rel="stylesheet">
    <title>Administrador</title>
</head>
<header class="py-3 shadow-sm merriweather-font">
  <div class="container">
      <div class="row g-0 justify-content-between align-items-center">
          <!-- Logo + Título -->
          <div class="col-auto d-flex align-items-center ps-2">
              <img src="img/Logo Vibra Positiva.jpg" alt="Logo" class="minilogo me-2">
              <h1 class="titulo fw-bold text-uppercase mb-0 fs-7 ms-2">Vibra Positiva Pijamas</h1>
          </div>
          <nav class="menu col-auto d-flex flex-column flex-md-row align-items-center gap-1 gap-md-2">
              <a href="1. index.html" class="co1 d-flex align-items-center text-center text-black text-decoration-none">
                  <div class="login d-flex align-items-center gap-1">
                      <span>Volver</span>
                      <div class="icono">
                          <i class="bi bi-box-arrow-left"></i>
                      </div>
                  </div>
              </a>
          </nav>
      </div>
  </div>
</header>
<body>
<!-- BOTÓN HAMBURGUESA SOLO EN MÓVIL -->
<nav class="navbar navbar-light d-md-none">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu">
      <span class="navbar-toggler-icon"></span>
    </button>
  </div>
</nav>
<!-- CONTENEDOR PRINCIPAL -->
<div class="d-flex flex-column flex-md-row">
  <!-- SIDEBAR -->
  <div class="sidebar collapse d-md-block p-3" id="sidebarMenu">
    <div class="text-center text-white mb-4">
      <i class="bi bi-person-circle" style="font-size: 3rem;"></i>
      <h5 class="fw-bold mt-2">Nombre Administrador</h5>
    </div>

    <ul class="nav flex-column text-center">
      <li class="nav-item">
        <a href="#" class="nav-link custom-link" data-bs-toggle="modal" data-bs-target="#modalActualizarDatos">Actualizar Datos</a>
      </li>

      <li class="nav-item">
        <a href="6. CambiarContraseña.html" class="nav-link custom-link">Cambiar Contraseña</a>
      </li>

      <hr class="bg-light">

      <li class="nav-item">
        <a href="5. AdministrarEmpleados.html" class="nav-link custom-link">Administrar Empleados</a>
      </li>
      <li class="nav-item">
        <a href="7. AsignarTareas.html" class="nav-link custom-link">Asignar Tarea</a>
      </li>
      <li class="nav-item">
        <a href="#" class="nav-link custom-link">Administrar Asistencia</a>
      </li>
      <li class="nav-item">
        <a href="#" class="nav-link custom-link">Generar Horario de los Empleados</a>
      </li>
      <li class="nav-item">
        <a href="#" class="nav-link custom-link">Generar Reporte de Cumplimiento</a>
      </li>

      <hr class="bg-light">

      <li class="nav-item">
        <a href="#" class="nav-link custom-link">Administrar Inventario</a>
      </li>
      <li class="nav-item">
        <a href="#" class="nav-link custom-link">Agregar Productos</a>
      </li>
      <li class="nav-item">
        <a href="#" class="nav-link custom-link">Eliminar Productos</a>
      </li>
    </ul>
  </div>

  <!-- MODAL: ACTUALIZAR DATOS -->
  <div class="modal fade" id="modalActualizarDatos" tabindex="-1" aria-labelledby="modalActualizarDatosLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content rounded-3 shadow">
        <div class="modal-header bg-primary text-white">
          <h5 class="modal-title" id="modalActualizarDatosLabel">Actualizar Datos</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Cerrar"></button>
        </div>

        <form id="formActualizarDatos">
          <div class="modal-body bg-light">
            <div class="container">
              <div class="row g-3">
                <div class="col-md-6">
                  <label class="form-label">Primer Nombre</label>
                  <input type="text" class="form-control" name="primerNombre">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Edad</label>
                  <input type="number" class="form-control" name="edad">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Segundo Nombre</label>
                  <input type="text" class="form-control" name="segundoNombre">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Correo Electrónico</label>
                  <input type="email" class="form-control" name="correo">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Primer Apellido</label>
                  <input type="text" class="form-control" name="primerApellido">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Número de Teléfono</label>
                  <input type="tel" class="form-control" name="telefono">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Segundo Apellido</label>
                  <input type="text" class="form-control" name="segundoApellido">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Dirección</label>
                  <input type="text" class="form-control" name="direccion">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Num Documento</label>
                  <input type="text" class="form-control" name="documento">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Nacionalidad</label>
                  <input type="text" class="form-control" name="nacionalidad">
                </div>
              </div>

              <div class="text-center mt-4">
                <button type="submit" class="btn btn-primary px-4">Finalizar</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
  <!-- MAIN -->
  <main class="flex-grow-1 p-4 bg-light">
  <!-- FILA 1: TABLA DE EMPLEADOS -->
  <div class="row g-4 mb-4">
    <div class="col-12">
      <div class="card shadow-sm">
        <div class="card-header d-flex justify-content-between align-items-center">
          <span class="fw-bold">Empleados y Tareas</span>
          <div class="btn-group">
            <button class="btn btn-success btn-sm" id="btnAgregarEmpleado" title="Crear">
              <i class="bi bi-person-plus"></i>
            </button>
          </div>
        </div>
        <div class="card-body table-responsive">
          <table class="table table-bordered align-middle text-center">
            <thead>
              <tr>
                <th>ID</th>
                <th>Empleado</th>
                <th>Tareas Hechas</th>
                <th>Pendientes</th>
                <th>Total de Tareas</th>
                <th>Próxima Entrega</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody id="tablaEmpleados"></tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <!-- FILA 2: ESTADÍSTICAS, TOP Y CALENDARIO -->
  <div class="row g-4 align-items-stretch">
  <!-- Estadísticas -->
    <div class="col-12 col-md-4 h-100">
      <div class="card shadow-sm h-100">
        <div class="card-header fw-bold">Estadísticas</div>
        <div class="card-body">
          <canvas id="chartEstadisticas"></canvas>
        </div>
      </div>
    </div>
    <!-- Top 3 Empleados -->
    <div class="col-12 col-md-4 h-100">
      <div class="card shadow-sm h-100">
        <div class="card-header fw-bold">Top 3 Empleados</div>
        <div class="card-body">
          <ol class="list-group list-group-numbered" id="listaTopEmpleados">
            <!-- Se llenará con JS -->
          </ol>
        </div>
      </div>
    </div>
    <!-- Calendario -->
      <div class="col-12 col-md-4 h-100">
        <div class="card shadow-sm h-100">
          <div class="card-header fw-bold">Calendario</div>
          <div class="card-body p-0">
            <iframe src="https://calendar.google.com/calendar/embed?src=es.co%23holiday%40group.v.calendar.google.com&ctz=America%2FBogota"
            style="border: 0;" width="100%" height="300" frameborder="0" scrolling="no"></iframe>
          </div>
        </div>
      </div>
    </div>
  </main>
</div>

  <!-- MODAL PARA CREAR/EDITAR EMPLEADO -->
  <div class="modal fade" id="empleadoModal" tabindex="-1" aria-labelledby="empleadoModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <form id="formEmpleado">
          <div class="modal-header custom-header text-black">
            <h5 class="modal-title" id="empleadoModalLabel">Agregar Empleado</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
          </div>
          <div class="modal-body">
            <input type="hidden" id="modo" value="crear">
            <input type="hidden" id="filaEditar" value="">
            <div class="mb-3">
              <label for="nombreEmpleado" class="form-label">Nombre</label>
              <input type="text" class="form-control" id="nombreEmpleado" required>
            </div>
            <div class="mb-3">
              <label for="hechasEmpleado" class="form-label">Tareas Hechas</label>
              <input type="number" class="form-control" id="hechasEmpleado" required>
            </div>
            <div class="mb-3">
              <label for="pendientesEmpleado" class="form-label">Tareas Pendientes</label>
              <input type="number" class="form-control" id="pendientesEmpleado" required>
            </div>
            <div class="mb-3">
              <label for="entregaEmpleado" class="form-label">Fecha de Entrega</label>
              <input type="date" class="form-control" id="entregaEmpleado" required>
            </div>
          </div>
          <div class="modal-footer d-flex justify-content-center">
            <button type="button" class="btn btn-danger text-black" data-bs-dismiss="modal">Cancelar</button>
            <button type="submit" class="btn custom-btn text-black">Guardar</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  <!-- FOOTER -->
  <footer class="text-black pt-2 pb-3">
    <div class="container text-center">
      <div class="text-center mt-4 poiret-one-font fw-bold">
        <small>© 2025 Tienda de Pijamas Vibra Positiva - Todos los derechos reservados</small>
      </div>
    </div>
  </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="js/3. appadmin.js"></script>
</body>
</html>