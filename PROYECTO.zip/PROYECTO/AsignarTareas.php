<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/7. style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poiret+One&family=Prata&family=Savate:ital,wght@0,200..900;1,200..900&display=swap" rel="stylesheet">
    <title>Administrdor</title>
</head>
<header class="py-3 shadow-sm">
  <div class="container">
    <div class="row g-0 justify-content-between align-items-center">
        <!-- Logo + Título -->
        <div class="col-auto d-flex align-items-center ps-2">
            <img src="img/Logo Vibra Positiva.jpg" alt="Logo" class="minilogo me-2">
            <h1 class="titulo fw-bold text-uppercase mb-0 fs-7 ms-4 poiret-one-font">Vibra Positiva Pijamas</h1>
        </div>
        <nav class="menu col-auto d-flex flex-column flex-md-row align-items-center gap-1 gap-md-2">
            <a href="1. index.html" class="co1 px-3 d-flex align-items-center text-center text-black text-decoration-none">
                <div class="login poiret-one-font fw-bold d-flex align-items-center gap-1">
                    <span><a href="logout.php" class="btn btn-danger">Cerrar sesión</a>
</span>
                    <div class="icono">
                        <i class="bi bi-box-arrow-left"></i>
                    </div>
                </div>
            </a>
        </nav>
    </div>
  </div>
</header>
<body class="poiret-one-font fw-bold">
    <h1>Asignar Tarea a Empleados</h1>

  <!-- Formulario -->
  <div class="container formulario">
    <form>
      <div class="row g-3">
        <div class="col-md-6">
          <label for="idEmpleado" class="form-label">ID Empleado</label>
          <input type="text" class="form-control" id="idEmpleado" name="idEmpleado" required>
        </div>
        <div class="col-md-6">
          <label for="tarea" class="form-label">Tipo de Tarea</label>
          <input type="text" class="form-control" id="tarea" name="tarea" required>
        </div>
        <div class="col-md-6">
          <label for="fechaMin" class="form-label">Fecha Mínima de Entrega</label>
          <input type="date" class="form-control" id="fechaMin" name="fechaMin" required>
        </div>
        <div class="col-md-6">
          <label for="fechaMax" class="form-label">Fecha Límite de Entrega</label>
          <input type="date" class="form-control" id="fechaMax" name="fechaMax" required>
        </div>
        <div class="col-md-6">
          <label for="maquina" class="form-label">Tipo de Máquina a Usar</label>
          <input type="text" class="form-control" id="maquina" name="maquina" required>
        </div>
        <div class="col-md-6">
          <label for="tela" class="form-label">Tipo de Tela a Usar</label>
          <input type="text" class="form-control" id="tela" name="tela" required>
        </div>
      </div>

      <div class="buttons-row">
        <a href="3. Admin.html" class="btn btn-secondary">Cancelar</a>
        <button type="submit" class="btn btn-primary">Enviar</button>
</footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="js/6. appcambiarContraseña.js"></script>
</body>
</html>