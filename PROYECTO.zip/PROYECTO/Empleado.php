<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/4. styleEmpleado.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poiret+One&family=Prata&family=Savate:ital,wght@0,200..900;1,200..900&display=swap" rel="stylesheet">
    <title>Empleado</title>
</head>
<header class="py-3 shadow-sm">
  <div class="container">
    <div class="row g-0 justify-content-between align-items-center">
        <!-- Logo + Título -->
        <div class="col-auto d-flex align-items-center ps-2">
            <img src="img/Logo Vibra Positiva.jpg" alt="Logo" class="minilogo me-2">
            <h1 class="titulo fw-bold text-uppercase mb-0 fs-7 ms-4 poiret-one-font">Vibra Positiva Pijamas</h1>
        </div>
        <nav class="menu col-auto d-flex flex-column flex-md-row align-items-center gap-1 gap-md-2">
            <a href="1. index.html" class="co1 px-3 d-flex align-items-center text-center text-black text-decoration-none">
                <div class="login poiret-one-font fw-bold d-flex align-items-center gap-1">
                    <span><a href="logout.php" class="btn btn-danger">Cerrar sesión</a>
</span>
                    <div class="icono">
                        <i class="bi bi-box-arrow-left"></i>
                    </div>
                </div>
            </a>
        </nav>
    </div>
  </div>
</header>
<body>
    <div class="container mt-4">
    <div class="admin-header">
      <h1 class="admin-title">Bienvenid@ (nombre del empleado)</h1>
    </div>

    <div class="text-center my-3">
      <a href="17. ActualizarDatosEmpleado.html" class="small-btn">Actualizar Datos</a>
      <a href="18. CambiarContraseñaEmpleado.html" class="small-btn">Cambiar Contraseña</a>
      <a href="16. AsistenciaDesempeño.html" class="small-btn">Asistencia y Desempeño</a>
    </div>

    <div class="panel-blanco">
      <div class="empleado-left">
        <div class="menu-tareas">
          <h2>Menú de Tareas</h2>
          <div class="table-container">
            <table class="table table-bordered table-striped text-center align-middle">
              <thead class="table-primary">
                <tr>
                  <th>Tipo Pijama</th>
                  <th>Diseño</th>
                  <th>Cantidad</th>
                  <th>Tipo de Tela</th>
                  <th>Fecha Mínima de Entrega</th>
                  <th>Fecha Límite de Entrega</th>
                  <th>Completada</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Pijama Larga</td>
                  <td>Cuadros</td>
                  <td>12</td>
                  <td>Seda</td>
                  <td>30/11/2024</td>
                  <td>31/12/2024</td>
                  <td><input type="checkbox"></td>
                </tr>
                <tr>
                  <td>Corta</td>
                  <td>Navideña</td>
                  <td>12</td>
                  <td>Algodón</td>
                  <td>23/12/2024</td>
                  <td>31/12/2024</td>
                  <td><input type="checkbox"></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="empleado-right">
        <h2>Abril 2025</h2>
        <div id="calendar"></div>
      </div>
    </div>
  </div>
<footer class="text-black pt-2 pb-3">
    <div class="container text-center">
      <div class="text-center mt-4 poiret-one-font fw-bold">
        <small>© 2025 Tienda de Pijamas Vibra Positiva - Todos los derechos reservados</small>
      </div>
    </div>
  </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="js/4. appempleado.js"></script>
</body>
</html>