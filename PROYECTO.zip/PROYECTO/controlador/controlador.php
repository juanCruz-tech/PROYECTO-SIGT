<?php


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);



require "../modeloDao/personaDao.php";
require "../modeloDto/personaDto.php";
require "../conexion/conexion.php";




if (isset($_POST['registro'])) {
    // Validar que las contraseñas coincidan
    if ($_POST['contrasena'] !== $_POST['confirmarContrasena']) {
        header("Location:../registro.php?mensaje=Las contraseñas no coinciden");
        exit;
    }

    $uDao = new PersonaDao();
    $uDto = new UsuarioDto();

    // Asignar datos del formulario al DTO
    $uDto->setTipoDocumento($_POST['tipoDocumento']);
    $uDto->setNumeroDocumento($_POST['numeroDocumento']);
    $uDto->setPrimerNombre($_POST['primerNombre']);
    $uDto->setSegundoNombre($_POST['segundoNombre']);
    $uDto->setCorreo($_POST['correo']);
    $uDto->setPrimerApellido($_POST['primerApellido']);
    $uDto->setSegundoApellido($_POST['segundoApellido']);
    $uDto->setRolPersona($_POST['rolPersona']);
    $uDto->setTelefono($_POST['telefono']);
   
    $hashedPassword = password_hash($_POST['contrasena'], PASSWORD_DEFAULT);
   $uDto->setContrasena($hashedPassword);


    // Registrar el usuario
    $mensaje = $uDao->registrarUsuario($uDto);

    // Redireccionar con mensaje
    header("Location:../registro.php?mensaje=" . urlencode($mensaje));
}
?>
