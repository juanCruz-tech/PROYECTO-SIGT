// Confirmar cambio de contraseña
    document.getElementById("formCambio").addEventListener("submit", function (e) {
      e.preventDefault();
      const modal = new bootstrap.Modal(document.getElementById("modalExito"));
      modal.show();
    });

    // Recuperar contraseña
    document.getElementById("formRecuperar").addEventListener("submit", function (e) {
      e.preventDefault();
      const tempPass = Math.random().toString(36).slice(-8);
      document.getElementById("claveTemporalReal").textContent = tempPass;
      document.getElementById("claveTemporalOculta").style.display = "inline";
      document.getElementById("claveTemporalReal").style.display = "none";
      document.getElementById("btnToggleClave").textContent = "Mostrar";

      const modal = new bootstrap.Modal(document.getElementById("modalTemporal"));
      bootstrap.Modal.getInstance(document.getElementById("modalRecuperar")).hide();
      setTimeout(() => modal.show(), 300);
    });

    // Mostrar/ocultar clave temporal
    document.getElementById("btnToggleClave").addEventListener("click", function () {
      const oculta = document.getElementById("claveTemporalOculta");
      const real = document.getElementById("claveTemporalReal");
      const btn = this;

      if (real.style.display === "none") {
        oculta.style.display = "none";
        real.style.display = "inline";
        btn.textContent = "Ocultar";
      } else {
        oculta.style.display = "inline";
        real.style.display = "none";
        btn.textContent = "Mostrar";
      }
    });