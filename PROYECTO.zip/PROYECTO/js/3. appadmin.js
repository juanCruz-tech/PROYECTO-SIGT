document.addEventListener('DOMContentLoaded', () => {
  const tabla = document.getElementById('tablaEmpleados');
  const modal = new bootstrap.Modal(document.getElementById('empleadoModal'));
  const form = document.getElementById('formEmpleado');

  const nombre = document.getElementById('nombreEmpleado');
  const hechas = document.getElementById('hechasEmpleado');
  const pendientes = document.getElementById('pendientesEmpleado');
  const entrega = document.getElementById('entregaEmpleado');
  const modo = document.getElementById('modo');
  const filaEditar = document.getElementById('filaEditar');

  // ABRIR MODAL PARA CREAR
  document.getElementById('btnAgregarEmpleado').addEventListener('click', () => {
    form.reset();
    modo.value = 'crear';
    filaEditar.value = '';
    document.getElementById('empleadoModalLabel').textContent = 'Agregar Empleado';
    modal.show();
  });

  // MANEJAR SUBMIT DEL FORMULARIO (crear o editar)
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const total = parseInt(hechas.value) + parseInt(pendientes.value);

    if (modo.value === 'crear') {
      const fila = crearFila(nombre.value, hechas.value, pendientes.value, total, entrega.value);
      tabla.appendChild(fila);
      actualizarTopEmpleados();
    } else {
      const fila = document.getElementById(filaEditar.value);
      const celdas = fila.querySelectorAll('td');
      celdas[1].textContent = nombre.value;
      celdas[2].textContent = hechas.value;
      celdas[3].textContent = pendientes.value;
      celdas[4].textContent = total;
      celdas[5].textContent = entrega.value;
      actualizarTopEmpleados();
    }

    modal.hide();
  });

  let contadorId = 1;
  // FUNCIÓN PARA CREAR UNA FILA CON BOTONES
  function crearFila(nombreVal, hechasVal, pendientesVal, totalVal, entregaVal) {
  const id = `empleado-${contadorId}`;
  const fila = document.createElement('tr');
  fila.id = id;

  fila.innerHTML = `
    <td>${contadorId}</td> <!-- ID visible en la tabla -->
    <td>${nombreVal}</td>
    <td>${hechasVal}</td>
    <td>${pendientesVal}</td>
    <td>${totalVal}</td>
    <td>${entregaVal}</td>
    <td>
      <button class="btn btn-warning btn-sm me-1 btn-editar" data-id="${id}" title="Editar">
        <i class="bi bi-pencil"></i>
      </button>
      <button class="btn btn-danger btn-sm btn-eliminar" data-id="${id}" title="Eliminar">
        <i class="bi bi-trash"></i>
      </button>
    </td>
  `;
  contadorId++;

  return fila;
}


  // EVENT DELEGATION PARA BOTONES DE ACCIÓN EN LA TABLA
  tabla.addEventListener('click', (e) => {
    if (e.target.closest('.btn-editar')) {
      const id = e.target.closest('.btn-editar').dataset.id;
      const fila = document.getElementById(id);
      const celdas = fila.querySelectorAll('td');
      nombre.value = celdas[0].textContent;

      nombre.value = celdas[1].textContent;
      hechas.value = celdas[2].textContent;
      pendientes.value = celdas[3].textContent;
      entrega.value = celdas[5].textContent;
      modo.value = 'editar';
      filaEditar.value = id;
      document.getElementById('empleadoModalLabel').textContent = 'Editar Empleado';
      modal.show();
    }

    if (e.target.closest('.btn-eliminar')) {
      const id = e.target.closest('.btn-eliminar').dataset.id;
      const fila = document.getElementById(id);
      if (confirm('¿Estás seguro de eliminar este empleado?')) {
        fila.remove();
        actualizarTopEmpleados();
      }
    }
  });
});

function actualizarTopEmpleados() {
  const lista = document.getElementById('listaTopEmpleados');
  const filas = document.querySelectorAll('#tablaEmpleados tr');
  const empleados = [];

  filas.forEach(fila => {
    const celdas = fila.querySelectorAll('td');
    const nombre = celdas[1].textContent;
    const hechas = parseInt(celdas[2].textContent);
    const pendientes = parseInt(celdas[3].textContent);
    const total = hechas + pendientes;
    const porcentaje = total > 0 ? Math.round((hechas / total) * 100) : 0;

    empleados.push({ nombre, porcentaje });
  });

  // Ordenar por porcentaje descendente y tomar top 3
  const top = empleados.sort((a, b) => b.porcentaje - a.porcentaje).slice(0, 3);

  // Renderizar en la lista
  lista.innerHTML = '';
  top.forEach(emp => {
    const badgeClass = emp.porcentaje >= 90 ? 'bg-success' :
                       emp.porcentaje >= 75 ? 'bg-info' :
                       emp.porcentaje >= 50 ? 'bg-warning' : 'bg-danger';

    lista.innerHTML += `
      <li class="list-group-item d-flex justify-content-between align-items-center">
        ${emp.nombre}
        <span class="badge ${badgeClass}">${emp.porcentaje}%</span>
      </li>
    `;
  });
}

//modal Actualizar Datos
document.getElementById('formActualizarDatos').addEventListener('submit', function (e) {
  e.preventDefault();
  alert('Datos actualizados correctamente');
  const modal = bootstrap.Modal.getInstance(document.getElementById('modalActualizarDatos'));
  modal.hide();
});

//modal actualizar contraseña
document.addEventListener('DOMContentLoaded', () => {
  const formCambiar = document.getElementById('formCambiarContrasena');
  const modalCambiar = bootstrap.Modal.getInstance(document.getElementById('modalCambiarContraseña'));
  const modalExito = new bootstrap.Modal(document.getElementById('modalExito'));
  const modalRecuperar = new bootstrap.Modal(document.getElementById('modalRecuperar'));
  const modalTemporal = new bootstrap.Modal(document.getElementById('modalTemporal'));

  const nueva = document.getElementById('nuevaContrasena');
  const repetir = document.getElementById('repetirContrasena');

  formCambiar.addEventListener('submit', function (e) {
    e.preventDefault();
    if (nueva.value !== repetir.value) {
      alert('Las contraseñas no coinciden.');
      return;
    }

    modalCambiar.hide();
    setTimeout(() => modalExito.show(), 400);
  });

  document.getElementById('linkOlvidoContrasena').addEventListener('click', (e) => {
    e.preventDefault();
    modalCambiar.hide();
    setTimeout(() => modalRecuperar.show(), 400);
  });

  document.getElementById('formRecuperar').addEventListener('submit', (e) => {
    e.preventDefault();
    modalRecuperar.hide();

    // Simular contraseña temporal
    const clave = generarClave(8);
    const claveSpan = document.getElementById('claveTemporal');
    claveSpan.textContent = clave;

    // Mostrar modal con contraseña temporal
    setTimeout(() => modalTemporal.show(), 400);

    // Botón mostrar/ocultar
    const btnToggle = document.getElementById('btnToggle');
    let visible = false;
    btnToggle.onclick = () => {
      visible = !visible;
      claveSpan.textContent = visible ? clave : '********';
      btnToggle.textContent = visible ? 'Ocultar' : 'Mostrar';
    };
  });

  function generarClave(length) {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
});
