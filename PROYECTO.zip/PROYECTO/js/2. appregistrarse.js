document.getElementById('formularioRegistro').addEventListener('submit', function (e) {
    e.preventDefault();

    const rol = document.getElementById('rol');
    const nombre = document.getElementById('nombre');
    const apellido = document.getElementById('apellido');
    const documento = document.getElementById('documento');
    const numDocumento = document.getElementById('numDocumento');
    const correo = document.getElementById('correo');
    const clave = document.getElementById('clave');
    const confirmarClave = document.getElementById('confirmarClave');

    let valido = true;

    const marcarInvalido = (campo, mensaje) => {
        campo.classList.add('is-invalid');
        const feedback = campo.parentElement.querySelector('.invalid-feedback');
        if (feedback) feedback.textContent = mensaje;
        valido = false;
    };

    document.querySelectorAll('.form-control, .form-select').forEach(c => c.classList.remove('is-invalid'));

    if (!rol.value) marcarInvalido(rol, 'Seleccione un rol');
    if (!nombre.value.trim()) marcarInvalido(nombre, 'El nombre es obligatorio');
    if (!apellido.value.trim()) marcarInvalido(apellido, 'El apellido es obligatorio');
    if (!documento.value) marcarInvalido(documento, 'Seleccione un tipo de documento');
    if (!numDocumento.value) marcarInvalido(numDocumento, 'Ingrese el número de documento');

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!correo.value.trim()) marcarInvalido(correo, 'El correo es obligatorio');
    else if (!emailRegex.test(correo.value)) marcarInvalido(correo, 'Ingrese un correo válido');

    if (!clave.value) marcarInvalido(clave, 'La contraseña es obligatoria');
    else if (clave.value.length < 6) marcarInvalido(clave, 'Mínimo 6 caracteres');

    
    if (valido) {
        const modal = new bootstrap.Modal(document.getElementById('modalExito'));
        modal.show();
    }
});

document.querySelectorAll('.toggle-password').forEach(btn => {
    btn.addEventListener('click', () => {
        const input = document.getElementById(btn.dataset.target);
        const icon = btn.querySelector('i');
        if (input.type === 'password') {
            input.type = 'text';
            icon.classList.remove('bi-eye');
            icon.classList.add('bi-eye-slash');
        } else {
            input.type = 'password';
            icon.classList.remove('bi-eye-slash');
            icon.classList.add('bi-eye');
        }
    });
});