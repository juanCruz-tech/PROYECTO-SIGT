<?php
class PersonaDao {
    public function registrarUsuario(UsuarioDto $usuarioDto){
        $cnn = Conexion::getConexion();
        $mensaje = "";

        try {
            $query = $cnn->prepare("INSERT INTO persona 
                (NumeroDocumento, Primer_Nombre, Segundo_Nombre, Primer_Apellido, Segundo_Apellido, rolPersona, Correo, telefono, contrasena) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

            $query->bindValue(1, $usuarioDto->getNumeroDocumento());
            $query->bindValue(2, $usuarioDto->getPrimerNombre());
            $query->bindValue(3, $usuarioDto->getSegundoNombre());
            $query->bindValue(4, $usuarioDto->getPrimerApellido());
            $query->bindValue(5, $usuarioDto->getSegundoApellido());
            $query->bindValue(6, $usuarioDto->getRolPersona());
            $query->bindValue(7, $usuarioDto->getCorreo());
            $query->bindValue(8, $usuarioDto->getTelefono());
            $query->bindValue(9, $usuarioDto->getContrasena());

            $query->execute();

            $mensaje = "Usuario registrado con éxito";
        } catch (Exception $ex) {
            $mensaje = $ex->getMessage();
        }

        $cnn = null;
        return $mensaje;
    }
}
?>




